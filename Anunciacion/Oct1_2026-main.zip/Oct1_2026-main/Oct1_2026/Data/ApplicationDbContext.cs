using Microsoft.EntityFrameworkCore;
using Oct1_2026.Models;

namespace Oct1_2026.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Customer> Customers { get; set; }
    }
}