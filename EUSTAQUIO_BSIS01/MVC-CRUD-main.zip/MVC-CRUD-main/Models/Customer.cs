namespace MVC_CRUD.Models
{

    public class Customer

    {

        public int Id { get; set; }

        public string CustomerName { get; set; } = "";

        public string ContactName { get; set; } = "";

        public string Email { get; set; } = "";

        public string Phone { get; set; } = "";

        public string Address { get; set; } = "";

        public string City { get; set; } = "";

        public string State { get; set; } = "";

        public int ZipCode { get; set; }

    }

}   